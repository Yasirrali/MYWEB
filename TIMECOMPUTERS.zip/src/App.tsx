/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useRef } from 'react';
import { 
  Camera, 
  Laptop, 
  Shield, 
  Search, 
  ShoppingCart, 
  Phone, 
  Mail, 
  ChevronRight, 
  Cpu, 
  Wifi, 
  Eye, 
  Zap,
  Menu,
  X,
  Clock,
  Trash2,
  Plus,
  Minus,
  Wrench,
  CheckCircle2,
  Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const WHATSAPP_NUMBER = "923332397549";

const CATEGORIES = [
  { id: 'cctv', name: 'Security Cameras', icon: Camera, count: '120+ Products' },
  { id: 'systems', name: 'Camera Systems', icon: Shield, count: '45+ Bundles' },
  { id: 'laptops', name: 'Laptops (Dell/HP)', icon: Laptop, count: '50+ Models' },
  { id: 'accessories', name: 'Laptop Accessories', icon: Laptop, count: '300+ Items' },
  { id: 'installation', name: 'Installation Services', icon: Wrench, count: 'Expert Setup' },
];

const FEATURES = [
  { icon: Eye, title: "4K Ultra HD", desc: "Crystal clear surveillance" },
  { icon: Zap, title: "PoE Powered", desc: "Single cable installation" },
  { icon: Cpu, title: "AI Detection", desc: "Smart human & vehicle alerts" },
  { icon: Clock, title: "24/7 Support", desc: "Expert technical assistance" },
];

const PRODUCTS = [
  // Security Cameras
  {
    id: 1,
    category: 'cctv',
    name: "4K Pro Bullet Camera",
    price: 25000,
    oldPrice: 32000,
    image: "https://picsum.photos/seed/cam1/400/400",
    tag: "Best Seller",
    features: ["4K Resolution", "Night Vision", "AI Motion"]
  },
  {
    id: 2,
    category: 'cctv',
    name: "Smart Dome IP Camera",
    price: 21000,
    oldPrice: 28000,
    image: "https://picsum.photos/seed/cam2/400/400",
    tag: "25% OFF",
    features: ["Wide Angle", "Built-in Mic", "PoE"]
  },
  {
    id: 5,
    category: 'cctv',
    name: "PTZ Speed Dome Camera",
    price: 42000,
    oldPrice: 55000,
    image: "https://picsum.photos/seed/ptz/400/400",
    tag: "360° View",
    features: ["20x Zoom", "Auto Tracking", "Weatherproof"]
  },
  {
    id: 10,
    category: 'cctv',
    name: "Solar Powered WiFi Camera",
    price: 36000,
    oldPrice: 45000,
    image: "https://picsum.photos/seed/solar/400/400",
    tag: "Eco Friendly",
    features: ["No Wires", "1080p HD", "Two-Way Audio"]
  },
  {
    id: 11,
    category: 'cctv',
    name: "Full Color Night Vision Turret",
    price: 26500,
    oldPrice: 35000,
    image: "https://picsum.photos/seed/turret/400/400",
    tag: "24/7 Color",
    features: ["F1.0 Aperture", "Warm Light", "PoE"]
  },
  // Camera Systems
  {
    id: 3,
    category: 'systems',
    name: "8-Channel NVR System",
    price: 85000,
    oldPrice: 98000,
    image: "https://picsum.photos/seed/nvr/400/400",
    tag: "Full Kit",
    features: ["2TB HDD", "Remote View", "4K Support"]
  },
  {
    id: 6,
    category: 'systems',
    name: "Wireless 4-Camera Kit",
    price: 70000,
    oldPrice: 85000,
    image: "https://picsum.photos/seed/wireless/400/400",
    tag: "Easy Setup",
    features: ["WiFi 6", "Plug & Play", "Mobile App"]
  },
  {
    id: 12,
    category: 'systems',
    name: "16-Channel Business NVR",
    price: 168000,
    oldPrice: 210000,
    image: "https://picsum.photos/seed/16ch/400/400",
    tag: "Enterprise",
    features: ["4TB HDD", "RAID Support", "Rack Mount"]
  },
  {
    id: 13,
    category: 'systems',
    name: "Hybrid 8-Channel DVR",
    price: 53000,
    oldPrice: 65000,
    image: "https://picsum.photos/seed/dvr/400/400",
    tag: "Value",
    features: ["Analog & IP", "H.265+", "Motion Alerts"]
  },
  // Laptops
  {
    id: 7,
    category: 'laptops',
    name: "Dell Latitude 5420 i5",
    price: 155000,
    oldPrice: 195000,
    image: "https://picsum.photos/seed/dell1/400/400",
    tag: "Dell",
    features: ["16GB RAM", "512GB SSD", "14\" FHD"]
  },
  {
    id: 8,
    category: 'laptops',
    name: "HP EliteBook 840 G8 i7",
    price: 190000,
    oldPrice: 240000,
    image: "https://picsum.photos/seed/hp1/400/400",
    tag: "HP",
    features: ["16GB RAM", "1TB SSD", "Touchscreen"]
  },
  {
    id: 14,
    category: 'laptops',
    name: "Dell XPS 13 9310",
    price: 250000,
    oldPrice: 310000,
    image: "https://picsum.photos/seed/xps/400/400",
    tag: "Premium",
    features: ["4K Display", "Intel Evo", "Ultra Thin"]
  },
  {
    id: 15,
    category: 'laptops',
    name: "HP Pavilion 15 Ryzen 7",
    price: 140000,
    oldPrice: 165000,
    image: "https://picsum.photos/seed/pavilion/400/400",
    tag: "Best Value",
    features: ["8GB RAM", "256GB SSD", "Backlit KB"]
  },
  // Laptop Accessories
  {
    id: 4,
    category: 'accessories',
    name: "Premium Docking Station",
    price: 36000,
    oldPrice: 45000,
    image: "https://picsum.photos/seed/dock/400/400",
    tag: "Accessory",
    features: ["Dual 4K", "USB-C", "Power Delivery"]
  },
  {
    id: 9,
    category: 'accessories',
    name: "Ergonomic Laptop Stand",
    price: 9800,
    oldPrice: 12500,
    image: "https://picsum.photos/seed/stand/400/400",
    tag: "Aluminum",
    features: ["Adjustable", "Cooling", "Foldable"]
  },
  {
    id: 16,
    category: 'cctv',
    name: "Ranger 2 Smart Camera",
    price: 12500,
    oldPrice: 16800,
    image: "https://picsum.photos/seed/ranger2/400/400",
    tag: "Smart Home",
    features: ["1080P Full HD", "Smart Tracking", "Human Detection", "Built-in Siren"]
  }
];

const INSTALLATION_PACKAGES = [
  {
    id: 'inst-1',
    name: "Home Basic Setup",
    desc: "Professional installation for residential properties with up to 4 cameras.",
    features: ["4 Cameras", "App Config", "1 Year Warranty"]
  },
  {
    id: 'inst-2',
    name: "Business Pro Setup",
    desc: "Full-scale installation for offices and retail shops with up to 8 cameras.",
    features: ["8 Cameras", "NVR Setup", "Remote Access", "On-site Training"]
  },
  {
    id: 'inst-3',
    name: "Enterprise Solution",
    desc: "Custom large-scale installation for warehouses or multi-floor buildings.",
    features: ["16+ Cameras", "Server Config", "Network Optimization", "Priority Support"]
  }
];

const INSTALLATION_STEPS = [
  { title: "Site Survey", desc: "We visit your location to identify the best camera angles and blind spots." },
  { title: "Strategic Mounting", desc: "Cameras are securely mounted using professional-grade brackets and weatherproofing." },
  { title: "Clean Wiring", desc: "All cables are neatly tucked away or concealed in conduits for a clean look." },
  { title: "System Config", desc: "We configure the NVR/DVR and connect it to your local network." },
  { title: "Mobile Setup", desc: "We install the app on your phone and show you how to monitor your property." },
];

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

const Logo = ({ className = "", variant = "dark" }: { className?: string; variant?: "light" | "dark" }) => {
  const isLight = variant === "light";
  return (
    <div className={`flex flex-col ${className}`}>
      <div className="flex items-baseline leading-none">
        <span className="text-2xl md:text-3xl font-black italic tracking-tighter text-[#A31D24] uppercase">
          TIME
        </span>
        <div className="flex items-center ml-1">
          <span className={`text-2xl md:text-3xl font-black italic tracking-tighter uppercase ${isLight ? "text-white" : "text-black"}`}>
            C
          </span>
          <div className="relative flex items-center justify-center">
            <span className={`text-2xl md:text-3xl font-black italic tracking-tighter uppercase ${isLight ? "text-white" : "text-black"}`}>
              O
            </span>
            {/* Camera Icon integrated into the 'O' */}
            <div className="absolute -top-3 -right-2 transform rotate-12">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M23 7L16 12L23 17V7Z" fill={isLight ? "white" : "black"} />
                <rect x="1" y="5" width="15" height="14" rx="2" fill={isLight ? "white" : "black"} />
                <circle cx="8.5" cy="12" r="2.5" fill={isLight ? "black" : "white"} />
              </svg>
            </div>
          </div>
          <span className={`text-2xl md:text-3xl font-black italic tracking-tighter uppercase ${isLight ? "text-white" : "text-black"}`}>
            MPUTERS
          </span>
        </div>
      </div>
      <div className={`text-[9px] md:text-[11px] font-bold tracking-tight mt-0.5 border-t pt-0.5 ${isLight ? "text-white/80 border-white/20" : "text-slate-800 border-slate-300"}`}>
        Experts in Security & Tech Solutions
      </div>
    </div>
  );
};

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const mainRef = useRef<HTMLElement>(null);

  const scrollToContent = () => {
    mainRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleCategorySelect = (categoryId: string | null) => {
    setActiveCategory(categoryId);
    setIsSearching(false);
    setIsMenuOpen(false);
    scrollToContent();
  };

  const cartCount = useMemo(() => cart.reduce((acc, item) => acc + item.quantity, 0), [cart]);
  const cartTotal = useMemo(() => cart.reduce((acc, item) => acc + (item.price * item.quantity), 0), [cart]);

  const filteredProducts = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const query = searchQuery.toLowerCase();
    return PRODUCTS.filter(p => 
      p.name.toLowerCase().includes(query) || 
      p.category.toLowerCase().includes(query) ||
      p.features.some(f => f.toLowerCase().includes(query)) ||
      p.tag.toLowerCase().includes(query)
    );
  }, [searchQuery]);

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (searchQuery.trim()) {
      setIsSearching(true);
      setActiveCategory(null);
      setIsMenuOpen(false);
      scrollToContent();
    }
  };

  const clearSearch = () => {
    setSearchQuery("");
    setIsSearching(false);
    scrollToContent();
  };

  const addToCart = (product: any) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { id: product.id, name: product.name, price: product.price, image: product.image, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (id: number) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: number, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const checkoutToWhatsApp = () => {
    const message = `*Order from TimeComputers Website*\n\n` +
      cart.map(item => `- ${item.name} (x${item.quantity}) - Rs. ${(item.price * item.quantity).toLocaleString()}`).join('\n') +
      `\n\n*Total: Rs. ${cartTotal.toLocaleString()}*`;
    
    const encoded = encodeURIComponent(message);
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encoded}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] font-sans text-slate-900">
      {/* Top Bar */}
      <div className="bg-[#0F172A] text-white py-2 px-4 text-xs sm:text-sm">
        <div className="max-w-7xl mx-auto flex flex-col sm:row justify-between items-center gap-2 sm:flex-row">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1"><Phone size={14} className="text-brand" /> 0333 2397549</span>
          </div>
          <div className="flex items-center gap-4 opacity-80">
            <button onClick={() => handleCategorySelect('support')} className="hover:text-brand transition-colors">Support</button>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between gap-4">
          {/* Logo */}
          <button onClick={() => setActiveCategory(null)} className="shrink-0 text-left">
            <Logo />
          </button>

          {/* Search Bar - Desktop */}
          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-xl relative">
            <input 
              type="text" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search cameras, laptops, accessories..." 
              className="w-full bg-slate-100 border-none rounded-none py-2.5 pl-5 pr-12 focus:ring-2 focus:ring-brand transition-all outline-none text-sm font-bold uppercase tracking-tight"
            />
            <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 bg-slate-900 text-white p-1.5 rounded-none hover:bg-brand transition-colors">
              <Search size={18} />
            </button>
          </form>

          {/* Actions */}
          <div className="flex items-center gap-3 sm:gap-6">
            <div className="hidden lg:flex flex-col items-end">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Free Shipping</span>
              <span className="text-xs font-black italic uppercase">Orders Over Rs. 50,000</span>
            </div>
            <button 
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 hover:bg-slate-100 rounded-none transition-colors group"
            >
              <ShoppingCart size={22} className="text-slate-700 group-hover:text-brand transition-colors" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-brand text-white text-[10px] font-black w-5 h-5 flex items-center justify-center rounded-none border-2 border-white italic">
                  {cartCount}
                </span>
              )}
            </button>
            <button 
              className="md:hidden p-2 hover:bg-slate-100 rounded-none transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Navigation - Desktop */}
        <nav className="hidden md:block bg-slate-50 border-t border-slate-200">
          <div className="max-w-7xl mx-auto px-4">
            <ul className="space-center flex justify-center gap-10 py-4 text-xs font-black uppercase tracking-[0.2em] italic">
              <li 
                onClick={() => handleCategorySelect(null)}
                className={`pb-3 -mb-3 cursor-pointer transition-all ${!activeCategory ? "text-brand border-b-4 border-brand" : "hover:text-brand"}`}
              >
                Home
              </li>
              {CATEGORIES.map(cat => (
                <li 
                  key={cat.id}
                  onClick={() => handleCategorySelect(cat.id)}
                  className={`pb-3 -mb-3 cursor-pointer transition-all ${activeCategory === cat.id ? "text-brand border-b-4 border-brand" : "hover:text-brand"}`}
                >
                  {cat.name}
                </li>
              ))}
            </ul>
          </div>
        </nav>
      </header>

      {/* Cart Sidebar */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black/50 z-[60]"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="fixed right-0 top-0 h-full w-full max-w-md bg-white z-[70] shadow-2xl flex flex-col"
            >
              <div className="p-6 border-b border-slate-200 flex items-center justify-between">
                <h3 className="text-xl font-black text-slate-900 flex items-center gap-2">
                  <ShoppingCart size={20} /> YOUR CART
                </h3>
                <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-6">
                    <ShoppingCart size={80} className="opacity-10" />
                    <p className="font-black italic uppercase tracking-widest">Your cart is empty</p>
                    <button 
                      onClick={() => { setIsCartOpen(false); scrollToContent(); }}
                      className="bg-slate-900 text-white px-10 py-4 rounded-none font-black italic uppercase hover:bg-brand transition-all shadow-xl"
                    >
                      Start Shopping
                    </button>
                  </div>
                ) : (
                  cart.map(item => (
                    <div key={item.id} className="flex gap-4 group">
                      <div className="w-24 h-24 bg-slate-100 rounded-none overflow-hidden shrink-0 border-b-2 border-transparent group-hover:border-brand transition-all">
                        <img src={item.image} alt={item.name} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-black italic uppercase tracking-tight text-slate-900 text-sm leading-none mb-1">{item.name}</h4>
                        <p className="text-brand font-black italic mt-1 text-lg">Rs. {item.price.toLocaleString()}</p>
                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden">
                            <button onClick={() => updateQuantity(item.id, -1)} className="p-1 hover:bg-slate-100">
                              <Minus size={14} />
                            </button>
                            <span className="px-3 text-sm font-bold">{item.quantity}</span>
                            <button onClick={() => updateQuantity(item.id, 1)} className="p-1 hover:bg-slate-100">
                              <Plus size={14} />
                            </button>
                          </div>
                          <button onClick={() => removeFromCart(item.id)} className="text-slate-400 hover:text-red-500">
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {cart.length > 0 && (
                <div className="p-6 border-t border-slate-200 bg-slate-50 space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 font-bold">Subtotal</span>
                    <span className="text-2xl font-black text-slate-900">Rs. {cartTotal.toLocaleString()}</span>
                  </div>
                  <button 
                    onClick={checkoutToWhatsApp}
                    className="w-full bg-green-600 hover:bg-green-700 text-white py-4 rounded-xl font-black flex items-center justify-center gap-3 transition-all shadow-lg shadow-green-600/20"
                  >
                    <Phone size={20} /> CHECKOUT VIA WHATSAPP
                  </button>
                  <p className="text-[10px] text-center text-slate-400 uppercase tracking-widest font-bold">
                    Secure checkout via WhatsApp Business
                  </p>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden bg-white border-b border-slate-200 absolute w-full z-40 shadow-xl"
          >
            <div className="p-4 space-y-4">
              <div className="flex justify-center mb-4">
                <Logo />
              </div>
              <form onSubmit={handleSearch} className="relative">
                <input 
                  type="text" 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search..." 
                  className="w-full bg-slate-100 border-none rounded-lg py-3 px-4 outline-none"
                />
                <button type="submit" className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400">
                  <Search size={20} />
                </button>
              </form>
              <ul className="space-y-4 font-black uppercase italic tracking-tight text-slate-700">
                <li 
                  onClick={() => handleCategorySelect(null)}
                  className={!activeCategory ? "text-brand" : ""}
                >
                  Home
                </li>
                {CATEGORIES.map(cat => (
                  <li 
                    key={cat.id}
                    onClick={() => handleCategorySelect(cat.id)}
                    className={activeCategory === cat.id ? "text-brand" : ""}
                  >
                    {cat.name}
                  </li>
                ))}
                <li 
                  onClick={() => handleCategorySelect('support')}
                  className={activeCategory === 'support' ? "text-brand" : ""}
                >
                  Support
                </li>
              </ul>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <main ref={mainRef}>
        {isSearching ? (
          <section className="py-20 bg-white min-h-[60vh]">
            <div className="max-w-7xl mx-auto px-4">
              <div className="flex items-center justify-between mb-12">
                <div className="flex items-center gap-4">
                  <button 
                    onClick={clearSearch}
                    className="p-2 hover:bg-slate-100 rounded-full transition-colors"
                  >
                    <X size={24} />
                  </button>
                  <div>
                    <h3 className="text-4xl font-black text-slate-900 tracking-tighter uppercase italic">
                      SEARCH RESULTS: "{searchQuery}"
                    </h3>
                    <div className="h-2 w-24 bg-brand mt-2"></div>
                  </div>
                </div>
                <p className="text-slate-500 font-black italic uppercase tracking-widest text-sm">{filteredProducts.length} Products Found</p>
              </div>

              {filteredProducts.length === 0 ? (
                <div className="text-center py-24 bg-slate-50 rounded-none border-4 border-dashed border-slate-200">
                  <Search size={64} className="mx-auto text-slate-300 mb-6" />
                  <h4 className="text-3xl font-black italic text-slate-900 mb-4 uppercase">No products found</h4>
                  <p className="text-slate-500 mb-10 font-medium">Try searching for something else like "Dell", "Camera", or "HP".</p>
                  <button 
                    onClick={clearSearch}
                    className="bg-slate-900 text-white px-12 py-4 rounded-none font-black italic uppercase transition-all hover:bg-brand"
                  >
                    Clear Search
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10">
                  {filteredProducts.map((product) => (
                    <motion.div 
                      key={product.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      whileHover={{ y: -12 }}
                      className="group"
                    >
                      <div className="relative bg-slate-100 rounded-none overflow-hidden aspect-square mb-6 border-b-4 border-transparent group-hover:border-brand transition-all">
                        <img 
                          src={product.image} 
                          alt={product.name} 
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 grayscale group-hover:grayscale-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute top-4 left-4 bg-brand text-white text-[10px] font-black px-4 py-1.5 rounded-none uppercase tracking-widest italic">
                          {product.tag}
                        </div>
                      </div>
                      <div className="space-y-3">
                        <h4 className="text-xl font-black italic text-slate-900 group-hover:text-brand transition-colors uppercase tracking-tight leading-none">{product.name}</h4>
                        <div className="flex items-baseline gap-3">
                          <span className="text-2xl font-black text-slate-900">Rs. {product.price.toLocaleString()}</span>
                          <span className="text-sm text-slate-400 line-through font-bold">Rs. {product.oldPrice.toLocaleString()}</span>
                        </div>
                        <div className="pt-2 flex flex-wrap gap-2">
                          {product.features.map((f, i) => (
                            <span key={i} className="text-[10px] font-black bg-slate-100 text-slate-500 px-3 py-1 rounded-none uppercase tracking-tighter italic border border-slate-200">
                              {f}
                            </span>
                          ))}
                        </div>
                        <button 
                          onClick={() => addToCart(product)}
                          className="w-full mt-6 bg-slate-900 text-white py-4 rounded-none font-black italic uppercase hover:bg-brand transition-all flex items-center justify-center gap-3 shadow-xl group-hover:shadow-brand/20"
                        >
                          <ShoppingCart size={20} /> Add to Cart
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </section>
        ) : activeCategory === 'installation' ? (
          <section className="py-20 bg-slate-950 text-white min-h-[60vh] relative overflow-hidden bg-grid">
            <div className="absolute top-0 right-0 w-1/2 h-full bg-brand skew-x-12 translate-x-1/4 opacity-10 blur-3xl"></div>
            <div className="max-w-7xl mx-auto px-4 relative">
              <div className="flex items-center gap-4 mb-12">
                <button 
                  onClick={() => handleCategorySelect(null)}
                  className="p-2 hover:bg-white/10 rounded-none transition-colors border border-white/10"
                >
                  <X size={24} />
                </button>
                <div>
                  <h3 className="text-5xl font-black tracking-tighter uppercase italic">
                    INSTALLATION <span className="text-brand">SERVICES</span>
                  </h3>
                  <div className="h-2 w-24 bg-brand mt-2"></div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-24">
                {INSTALLATION_PACKAGES.map((pkg) => (
                  <motion.div 
                    key={pkg.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    whileHover={{ y: -12 }}
                    className="bg-white/5 border-l-4 border-brand p-10 rounded-none backdrop-blur-sm flex flex-col shadow-2xl"
                  >
                    <h4 className="text-3xl font-black italic uppercase mb-4 tracking-tight">{pkg.name}</h4>
                    <p className="text-slate-400 text-sm mb-8 flex-1 font-medium leading-relaxed">{pkg.desc}</p>
                    <ul className="space-y-4 mb-10">
                      {pkg.features.map((f, i) => (
                        <li key={i} className="flex items-center gap-3 text-xs font-black uppercase tracking-widest italic">
                          <CheckCircle2 className="text-brand" size={18} />
                          {f}
                        </li>
                      ))}
                    </ul>
                    <button 
                      onClick={() => window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=I'm interested in the ${pkg.name} installation package.`, '_blank')}
                      className="w-full bg-brand hover:bg-brand/90 text-white py-4 rounded-none font-black italic uppercase transition-all shadow-xl shadow-brand/20"
                    >
                      Get a Free Quote
                    </button>
                  </motion.div>
                ))}
              </div>

              {/* How We Install */}
              <div className="mb-32">
                <div className="text-center mb-16">
                  <h4 className="text-4xl font-black italic mb-4">OUR INSTALLATION <span className="text-brand">PROCESS</span></h4>
                  <p className="text-slate-400 font-bold uppercase tracking-widest">Step-by-step professional setup for your peace of mind.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                  {INSTALLATION_STEPS.map((step, i) => (
                    <div key={i} className="relative p-8 bg-slate-900 rounded-none border-t-4 border-brand text-center shadow-xl">
                      <div className="w-14 h-14 bg-brand rounded-none flex items-center justify-center font-black italic text-2xl mx-auto mb-6 -mt-12 shadow-lg">
                        {i + 1}
                      </div>
                      <h5 className="font-black italic mb-3 text-sm uppercase tracking-wider">{step.title}</h5>
                      <p className="text-xs text-slate-400 leading-relaxed font-medium">{step.desc}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Trust Section */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
                <div className="space-y-10">
                  <div className="text-left mb-12">
                    <h4 className="text-5xl font-black italic mb-6 leading-none">WHY TRUST <br /><span className="text-brand">TIMECOMPUTERS?</span></h4>
                    <p className="text-slate-400 font-medium text-lg">We have secured hundreds of homes and businesses across the region with a 100% satisfaction rate.</p>
                  </div>
                  <div className="flex items-start gap-8">
                    <div className="bg-brand p-5 rounded-none shrink-0 shadow-lg shadow-brand/20">
                      <Shield className="text-white" size={40} />
                    </div>
                    <div>
                      <h5 className="text-2xl font-black italic mb-3 uppercase">Certified Security Experts</h5>
                      <p className="text-slate-400 font-medium">Our team consists of certified technicians who specialize in complex surveillance networking and hardware.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-8">
                    <div className="bg-slate-800 p-5 rounded-none shrink-0">
                      <CheckCircle2 className="text-brand" size={40} />
                    </div>
                    <div>
                      <h5 className="text-2xl font-black italic mb-3 uppercase">Quality Guarantee</h5>
                      <p className="text-slate-400 font-medium">We only use genuine, high-quality hardware and provide a full 1-year service warranty on all installations.</p>
                    </div>
                  </div>
                </div>
                <div className="relative">
                  <div className="absolute -inset-4 border-2 border-brand/30 translate-x-4 translate-y-4 -z-10"></div>
                  <img 
                    src="https://picsum.photos/seed/trust-install/800/600" 
                    alt="Professional Installation" 
                    className="rounded-none shadow-2xl grayscale hover:grayscale-0 transition-all duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute -bottom-10 -right-10 bg-brand p-10 rounded-none shadow-2xl hidden sm:block">
                    <p className="text-6xl font-black italic leading-none">500+</p>
                    <p className="text-xs font-black uppercase tracking-[0.2em] mt-2 opacity-80">Systems Installed</p>
                  </div>
                </div>
              </div>
            </div>
          </section>
        ) : activeCategory === 'support' ? (
          <section className="py-20 bg-white min-h-[60vh]">
            <div className="max-w-3xl mx-auto px-4">
              <div className="flex items-center gap-4 mb-12">
                <button 
                  onClick={() => handleCategorySelect(null)}
                  className="p-2 hover:bg-slate-100 rounded-full transition-colors"
                >
                  <X size={24} />
                </button>
                <div>
                  <h3 className="text-4xl font-black text-slate-900 tracking-tighter uppercase italic">
                    SUPPORT & <span className="text-brand">INQUIRY</span>
                  </h3>
                  <div className="h-2 w-24 bg-brand mt-2"></div>
                </div>
              </div>

              <div className="bg-slate-50 border-4 border-slate-900 p-8 sm:p-12 shadow-[20px_20px_0px_0px_rgba(163,29,36,0.1)]">
                <div className="mb-10">
                  <h4 className="text-2xl font-black italic uppercase mb-2">CCTV Installation Inquiry</h4>
                  <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">Fill out the form below and our experts will contact you within 24 hours.</p>
                </div>

                <form action="https://formspree.io/f/mzdaodww" method="POST" className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-black uppercase tracking-widest italic text-slate-500">Full Name</label>
                      <input 
                        type="text" 
                        name="name" 
                        required 
                        placeholder="John Doe"
                        className="w-full bg-white border-2 border-slate-200 rounded-none py-4 px-5 outline-none focus:border-brand transition-colors font-bold"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-black uppercase tracking-widest italic text-slate-500">Phone Number</label>
                      <input 
                        type="tel" 
                        name="phone" 
                        required 
                        placeholder="03XX XXXXXXX"
                        className="w-full bg-white border-2 border-slate-200 rounded-none py-4 px-5 outline-none focus:border-brand transition-colors font-bold"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase tracking-widest italic text-slate-500">Installation Address</label>
                    <textarea 
                      name="address" 
                      required 
                      rows={2}
                      placeholder="Complete address for site survey"
                      className="w-full bg-white border-2 border-slate-200 rounded-none py-4 px-5 outline-none focus:border-brand transition-colors font-bold resize-none"
                    ></textarea>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-black uppercase tracking-widest italic text-slate-500">Number of Cameras</label>
                      <select 
                        name="cameras" 
                        className="w-full bg-white border-2 border-slate-200 rounded-none py-4 px-5 outline-none focus:border-brand transition-colors font-bold appearance-none"
                      >
                        <option value="1-4">1 - 4 Cameras</option>
                        <option value="5-8">5 - 8 Cameras</option>
                        <option value="9-16">9 - 16 Cameras</option>
                        <option value="16+">16+ Cameras (Enterprise)</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-black uppercase tracking-widest italic text-slate-500">Property Type</label>
                      <select 
                        name="property_type" 
                        className="w-full bg-white border-2 border-slate-200 rounded-none py-4 px-5 outline-none focus:border-brand transition-colors font-bold appearance-none"
                      >
                        <option value="residential">Residential (Home/Apartment)</option>
                        <option value="commercial">Commercial (Office/Shop)</option>
                        <option value="industrial">Industrial (Warehouse/Factory)</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase tracking-widest italic text-slate-500">Additional Requirements</label>
                    <textarea 
                      name="message" 
                      rows={4}
                      placeholder="Tell us about your specific security needs..."
                      className="w-full bg-white border-2 border-slate-200 rounded-none py-4 px-5 outline-none focus:border-brand transition-colors font-bold resize-none"
                    ></textarea>
                  </div>

                  <button 
                    type="submit"
                    className="w-full bg-brand hover:bg-brand/90 text-white py-5 rounded-none font-black italic uppercase transition-all shadow-2xl shadow-brand/40 text-xl"
                  >
                    Submit Inquiry
                  </button>
                </form>
              </div>
            </div>
          </section>
        ) : activeCategory ? (
          <section className="py-20 bg-white min-h-[60vh]">
            <div className="max-w-7xl mx-auto px-4">
              <div className="flex items-center gap-4 mb-12">
                <button 
                  onClick={() => handleCategorySelect(null)}
                  className="p-2 hover:bg-slate-100 rounded-full transition-colors"
                >
                  <X size={24} />
                </button>
                <div>
                  <h3 className="text-4xl font-black text-slate-900 tracking-tighter uppercase italic">
                    {CATEGORIES.find(c => c.id === activeCategory)?.name}
                  </h3>
                  <div className="h-2 w-24 bg-brand mt-2"></div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10">
                {PRODUCTS.filter(p => p.category === activeCategory).map((product) => (
                  <motion.div 
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    whileHover={{ y: -12 }}
                    className="group"
                  >
                    <div className="relative bg-slate-100 rounded-none overflow-hidden aspect-square mb-6 border-b-4 border-transparent group-hover:border-brand transition-all">
                      <img 
                        src={product.image} 
                        alt={product.name} 
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 grayscale group-hover:grayscale-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-4 left-4 bg-brand text-white text-[10px] font-black px-4 py-1.5 rounded-none uppercase tracking-widest italic">
                        {product.tag}
                      </div>
                    </div>
                    <div className="space-y-3">
                      <h4 className="text-xl font-black italic text-slate-900 group-hover:text-brand transition-colors uppercase tracking-tight leading-none">{product.name}</h4>
                      <div className="flex items-baseline gap-3">
                        <span className="text-2xl font-black text-slate-900">Rs. {product.price.toLocaleString()}</span>
                        <span className="text-sm text-slate-400 line-through font-bold">Rs. {product.oldPrice.toLocaleString()}</span>
                      </div>
                      <div className="pt-2 flex flex-wrap gap-2">
                        {product.features.map((f, i) => (
                          <span key={i} className="text-[10px] font-black bg-slate-100 text-slate-500 px-3 py-1 rounded-none uppercase tracking-tighter italic border border-slate-200">
                            {f}
                          </span>
                        ))}
                      </div>
                      <button 
                        onClick={() => addToCart(product)}
                        className="w-full mt-6 bg-slate-900 text-white py-4 rounded-none font-black italic uppercase hover:bg-brand transition-all flex items-center justify-center gap-3 shadow-xl group-hover:shadow-brand/20"
                      >
                        <ShoppingCart size={20} /> Add to Cart
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        ) : (
          <>
            {/* Hero Section */}
            <section className="relative bg-[#0F172A] overflow-hidden">
              <div className="absolute inset-0 opacity-20">
                <img 
                  src="https://picsum.photos/seed/security/1920/1080?blur=2" 
                  alt="Background" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="max-w-7xl mx-auto px-4 py-16 md:py-24 relative flex flex-col md:flex-row items-center gap-12">
                <div className="flex-1 text-center md:text-left">
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5 }}
                  >
                    <span className="inline-block bg-brand/20 text-brand px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-4">
                      Professional Surveillance & Tech
                    </span>
                    <h2 className="text-6xl md:text-8xl font-black text-white leading-[0.85] mb-8 uppercase italic tracking-tighter">
                      PREMIUM <br />
                      <span className="text-stroke">TECH</span> <br />
                      <span className="text-brand">FOR YOUR</span> <br />
                      BUSINESS.
                    </h2>
                    <p className="text-slate-400 text-lg mb-10 max-w-lg mx-auto md:mx-0 font-medium">
                      High-performance security cameras, Dell/HP Laptops, and expert tech solutions.
                    </p>
                    <div className="flex flex-col sm:flex-row items-center gap-4 justify-center md:justify-start">
                      <button 
                        onClick={() => handleCategorySelect('cctv')}
                        className="bg-brand hover:bg-brand/90 text-white px-10 py-5 rounded-none font-black uppercase italic transition-all flex items-center gap-2 group shadow-2xl shadow-brand/40"
                      >
                        Shop Cameras
                        <ChevronRight size={20} className="group-hover:translate-x-1 transition-transform" />
                      </button>
                      <button 
                        onClick={() => handleCategorySelect('laptops')}
                        className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-10 py-5 rounded-none font-black uppercase italic transition-all"
                      >
                        Shop Laptops
                      </button>
                    </div>
                  </motion.div>
                </div>
                <div className="flex-1 relative">
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.7, delay: 0.2 }}
                    className="relative z-10"
                  >
                    <img 
                      src="https://picsum.photos/seed/tech-hero/800/600" 
                      alt="Security Camera" 
                      className="rounded-none shadow-2xl border-l-8 border-brand grayscale hover:grayscale-0 transition-all duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-brand/10 blur-[100px] rounded-full -z-10"></div>
                </div>
              </div>
            </section>

            {/* Features Grid */}
            <section className="py-16 bg-white border-b border-slate-200">
              <div className="max-w-7xl mx-auto px-4">
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-10">
                  {FEATURES.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-5 group">
                      <div className="bg-slate-100 p-5 rounded-none group-hover:bg-brand transition-all shadow-sm">
                        <feature.icon className="text-slate-600 group-hover:text-white transition-colors" size={28} />
                      </div>
                      <div>
                        <h4 className="font-black italic text-slate-900 uppercase tracking-tight leading-none mb-1">{feature.title}</h4>
                        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{feature.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* CCTV Installation Service Banner (Image-inspired) */}
            <section className="relative bg-white overflow-hidden py-20 border-b-8 border-brand">
              {/* Geometric Red Accents */}
              <div className="absolute top-0 right-0 w-1/3 h-full bg-brand -skew-x-12 translate-x-1/2 opacity-100 hidden lg:block"></div>
              <div className="absolute top-0 right-0 w-1/4 h-full bg-brand -skew-x-12 translate-x-1/3 opacity-100 hidden lg:block"></div>
              
              <div className="max-w-7xl mx-auto px-4 relative flex flex-col lg:flex-row items-center gap-16">
                <div className="flex-1 space-y-8">
                  <div className="mb-4 flex justify-center lg:justify-start">
                    <Logo />
                  </div>
                  <div className="space-y-2 text-center lg:text-left">
                    <h3 className="text-4xl sm:text-7xl font-black tracking-tighter leading-none">
                      <span className="text-brand">CCTV</span> <br />
                      INSTALLATION <br />
                      SERVICES
                    </h3>
                    <p className="text-sm sm:text-xl font-bold text-slate-500 uppercase tracking-widest sm:tracking-[0.2em]">Continuous Security Surveillance</p>
                  </div>

                  <div className="space-y-6 text-center lg:text-left">
                    <h4 className="text-2xl sm:text-3xl font-black italic text-brand uppercase">Our Service:</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-md mx-auto lg:mx-0 text-left">
                      {[
                        'CCTV Setup', 'CCTV Inspection',
                        'CCTV Servicing', 'CCTV Troubleshooting'
                      ].map((service, i) => (
                        <div key={i} className="flex items-center gap-3">
                          <div className="bg-brand rounded-full p-1">
                            <CheckCircle2 className="text-white" size={16} />
                          </div>
                          <span className="font-black italic uppercase text-slate-800 tracking-tight">{service}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex justify-center lg:justify-start">
                    <button 
                      onClick={() => window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=I need CCTV installation services.`, '_blank')}
                      className="w-full sm:w-auto bg-brand hover:bg-brand/90 text-white px-12 py-5 rounded-none font-black uppercase italic transition-all shadow-2xl shadow-brand/40 text-lg sm:text-xl"
                    >
                      Contact Us
                    </button>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-6 sm:gap-8 pt-8 border-t border-slate-100 items-center lg:items-start">
                    <div className="flex items-center gap-3">
                      <div className="bg-brand p-2 rounded-full shrink-0">
                        <Phone className="text-white" size={18} />
                      </div>
                      <span className="font-black text-lg sm:text-xl italic">0333 2397549</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-brand p-2 rounded-full shrink-0">
                        <Globe className="text-white" size={18} />
                      </div>
                      <span className="font-black text-lg sm:text-xl italic">www.timecomputers.com</span>
                    </div>
                  </div>
                </div>

                <div className="flex-1 relative w-full max-w-2xl mt-12 lg:mt-0">
                  {/* Hexagonal Image Grid */}
                  <div className="grid grid-cols-2 gap-3 sm:gap-4">
                    <div className="space-y-4">
                      <div className="aspect-square bg-slate-100 overflow-hidden" style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }}>
                        <img src="https://picsum.photos/seed/cam1/600/600" alt="CCTV 1" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500" />
                      </div>
                      <div className="aspect-square bg-slate-100 overflow-hidden sm:translate-x-1/2" style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }}>
                        <img src="https://picsum.photos/seed/cam2/600/600" alt="CCTV 2" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500" />
                      </div>
                    </div>
                    <div className="space-y-4 sm:-translate-y-1/4">
                      <div className="aspect-square bg-slate-100 overflow-hidden" style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }}>
                        <img src="https://picsum.photos/seed/cam3/600/600" alt="CCTV 3" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500" />
                      </div>
                      <div className="aspect-square bg-slate-100 overflow-hidden" style={{ clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }}>
                        <img src="https://picsum.photos/seed/cam4/600/600" alt="CCTV 4" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500" />
                      </div>
                    </div>
                  </div>
                  {/* Floating Hexagon Accent */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-brand/20 blur-3xl -z-10"></div>
                </div>
              </div>
            </section>

            {/* Categories Section */}
            <section className="py-20 bg-[#F8F9FA]">
              <div className="max-w-7xl mx-auto px-4">
                <div className="flex justify-between items-end mb-12">
                  <div>
                    <h3 className="text-4xl font-black text-slate-900 tracking-tighter uppercase italic">SHOP BY CATEGORY</h3>
                    <div className="h-2 w-24 bg-brand mt-2"></div>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {CATEGORIES.map((cat) => (
                    <motion.div 
                      key={cat.id}
                      onClick={() => handleCategorySelect(cat.id)}
                      whileHover={{ y: -5 }}
                      className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm hover:shadow-xl transition-all cursor-pointer group"
                    >
                      <div className="bg-slate-50 w-16 h-16 rounded-none flex items-center justify-center mb-6 group-hover:bg-brand transition-colors">
                        <cat.icon className="text-slate-400 group-hover:text-white transition-colors" size={32} />
                      </div>
                      <h4 className="text-xl font-black italic text-slate-900 mb-2 uppercase tracking-tight">{cat.name}</h4>
                      <p className="text-slate-500 text-sm mb-4 font-medium">{cat.count}</p>
                      <div className="flex items-center gap-2 text-brand font-black italic text-sm uppercase tracking-widest">
                        Browse Now <ChevronRight size={16} />
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </section>

            {/* Featured Products Grid */}
            <section className="py-20 bg-white">
              <div className="max-w-7xl mx-auto px-4">
                <div className="text-center mb-16">
                  <h3 className="text-3xl font-black text-slate-900 tracking-tight">FEATURED PRODUCTS</h3>
                  <p className="text-slate-500 mt-4 max-w-2xl mx-auto">
                    Our top-rated security equipment and premium laptops.
                  </p>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10">
                  {PRODUCTS.slice(0, 8).map((product) => (
                    <motion.div 
                      key={product.id}
                      whileHover={{ y: -12 }}
                      className="group"
                    >
                      <div className="relative bg-slate-100 rounded-none overflow-hidden aspect-square mb-6 border-b-4 border-transparent group-hover:border-brand transition-all">
                        <img 
                          src={product.image} 
                          alt={product.name} 
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 grayscale group-hover:grayscale-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute top-4 left-4 bg-brand text-white text-[10px] font-black px-4 py-1.5 rounded-none uppercase tracking-widest italic">
                          {product.tag}
                        </div>
                      </div>
                      <div className="space-y-3">
                        <h4 className="text-xl font-black italic text-slate-900 group-hover:text-brand transition-colors uppercase tracking-tight leading-none">{product.name}</h4>
                        <div className="flex items-baseline gap-3">
                          <span className="text-2xl font-black text-slate-900">Rs. {product.price.toLocaleString()}</span>
                          <span className="text-sm text-slate-400 line-through font-bold">Rs. {product.oldPrice.toLocaleString()}</span>
                        </div>
                        <div className="pt-2 flex flex-wrap gap-2">
                          {product.features.map((f, i) => (
                            <span key={i} className="text-[10px] font-black bg-slate-100 text-slate-500 px-3 py-1 rounded-none uppercase tracking-tighter italic border border-slate-200">
                              {f}
                            </span>
                          ))}
                        </div>
                        <button 
                          onClick={() => addToCart(product)}
                          className="w-full mt-6 bg-slate-900 text-white py-4 rounded-none font-black italic uppercase hover:bg-brand transition-all flex items-center justify-center gap-3 shadow-xl group-hover:shadow-brand/20"
                        >
                          <ShoppingCart size={20} /> Add to Cart
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
                <div className="text-center mt-20">
                  <button 
                    onClick={() => setActiveCategory('cctv')}
                    className="border-4 border-slate-900 text-slate-900 px-12 py-5 rounded-none font-black italic uppercase tracking-widest hover:bg-slate-900 hover:text-white transition-all shadow-2xl"
                  >
                    View All Products
                  </button>
                </div>
              </div>
            </section>
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-[#0F172A] text-white pt-20 pb-10">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          <div className="space-y-6">
            <Logo variant="light" />
            <p className="text-slate-400 text-sm leading-relaxed">
              Leading provider of CCTV security solutions and premium laptops from Dell and HP.
            </p>
          </div>

          <div>
            <h4 className="font-black italic uppercase tracking-widest text-lg mb-8">Quick Links</h4>
            <ul className="space-y-4 text-slate-400 text-sm font-black uppercase tracking-tight">
              <li onClick={() => handleCategorySelect(null)} className="hover:text-brand transition-colors cursor-pointer">Home</li>
              <li onClick={() => handleCategorySelect('cctv')} className="hover:text-brand transition-colors cursor-pointer">Security Cameras</li>
              <li onClick={() => handleCategorySelect('installation')} className="hover:text-brand transition-colors cursor-pointer">Installation</li>
              <li onClick={() => handleCategorySelect('laptops')} className="hover:text-brand transition-colors cursor-pointer">Laptops</li>
              <li onClick={() => handleCategorySelect('support')} className="hover:text-brand transition-colors cursor-pointer">Support Center</li>
            </ul>
          </div>

          <div>
            <h4 className="font-black italic uppercase tracking-widest text-lg mb-8">Categories</h4>
            <ul className="space-y-4 text-slate-400 text-sm font-black uppercase tracking-tight">
              <li onClick={() => handleCategorySelect('cctv')} className="hover:text-brand transition-colors cursor-pointer">Security Cameras</li>
              <li onClick={() => handleCategorySelect('systems')} className="hover:text-brand transition-colors cursor-pointer">Camera Systems</li>
              <li onClick={() => handleCategorySelect('laptops')} className="hover:text-brand transition-colors cursor-pointer">Dell/HP Laptops</li>
              <li onClick={() => handleCategorySelect('accessories')} className="hover:text-brand transition-colors cursor-pointer">Accessories</li>
            </ul>
          </div>

          <div>
            <h4 className="font-black italic uppercase tracking-widest text-lg mb-8">Contact Us</h4>
            <ul className="space-y-6">
              <li className="flex gap-4">
                <Phone className="text-brand shrink-0" size={20} />
                <span className="text-slate-400 text-sm font-bold uppercase tracking-tight">0333 2397549</span>
              </li>
              <li className="flex gap-4">
                <Mail className="text-brand shrink-0" size={20} />
                <span className="text-slate-400 text-sm font-bold uppercase tracking-tight">sales@timecomputers.com</span>
              </li>
              <li className="flex gap-4">
                <Globe className="text-brand shrink-0" size={20} />
                <span className="text-slate-400 text-xs font-bold uppercase tracking-tight leading-relaxed">
                  Shop 1, Sumaira Heights Apartments, mosmiyat 35, near subhan Allah hotel, Gulzar-e-Hijri Scheme 33, Karachi, 75800
                </span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-center md:text-left">
          <p className="text-slate-500 text-xs">
            © 2026 TimeComputers. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
